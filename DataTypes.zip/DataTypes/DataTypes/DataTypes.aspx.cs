﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DataTypes
{
    public partial class DataTypes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void goButton_Click(object sender, EventArgs e)
        {

            //Lesson 08



            /*
            int i;
            i = 5;
            */

            /*
            int i = 20000000000;
            long j = 1;
            */

            /*
            long i = 20000000000;
            int j = (int)i;
            */

            //double k = 2.5;
            //int j = (int)k;

            //resultLabel.Text;
            //resultLabel.Text = (string)j;
            //resultLabel.Text = j ToString();


            /*
            string i = eantryTextBox.Text;
            int j = int.Parse(i);
            int k = j + 1;
            resultLabel.Text = k.ToString();
            */






            //lesson 09



            //int i = 1;
            //int j = 2;
            //int result = i + j;
            //int result = i - j;
            //int result = i * j;
            //int result = i / j;


            /*
            i = i + 5;
            i +=1;
            i++;
            i--;
            */

            //int myInteger = 5 + 1 * 7;
            //resultLabel.Text = myInteger.ToString();

            /*
            double myDouble = 5.5;
            int myInteger = 7;
            int myOtherInteger = 4;
            */


            //double myResult = myDouble + myInteger;
            //int myResult = (int)myDouble + myInteger; //will get rid of the decimal when you convert to int
            //int myResult = myInteger / myOtherInteger;
            //double myResult = (double)myInteger / (double)myOtherInteger; //We convert the ints into doubles to get a decimal outcome
            //resultLabel.Text = myResult.ToString();

            //The following doesnt work the right way by design. int and long cant hold the value
            /*
            int firstNumber = 2000000000;
            int secondNumber = 2000000000;
            long resultNumber; = firstNumber * secondNumber;
            

            checked
            {
                resultNumber = firstNumber * secondNumber;
            }

            resultLabel.Text = resultNumber.ToString();
            */





            //Lesson 10











        }
    }
}